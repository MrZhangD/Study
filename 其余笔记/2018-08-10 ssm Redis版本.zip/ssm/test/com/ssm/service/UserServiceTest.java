package com.ssm.service;

import com.ssm.entity.Role;
import com.ssm.entity.User;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;
import java.util.UUID;

import static org.junit.Assert.*;

// @RunWith(SpringJUnit4ClassRunner.class)
// @ContextConfiguration(locations = {"classpath:spring/spring-dao.xml", "classpath:spring/spring-service.xml"})
public class UserServiceTest {

    @Autowired
    public UserService userService;


    @Test
    public void getAll() {
        List<User> list = userService.getAll();
        for (User item : list) {
            System.out.println(item);
            System.out.println("    " + item.getRoles());
        }
    }


    @Test
    public void getByEmail(){
        String email = "admin1@qq.com";
        User result = userService.getByEmail(email);
        System.out.println(result);
    }


    @Test
    public void updateRoles(){
        boolean result = userService.updateRoles(1, new int[]{2,4});
        System.out.println(result);
    }


    @Test
    public void getById(){
        User user = userService.getById(1);
        System.out.println(user);
        System.out.println(user.getRoles());
    }

    @Test
    public void testUUID(){
        UUID uuid = UUID.randomUUID();
        System.out.println(uuid.toString());
    }


    public UserService getUserService() {
        return userService;
    }
    public void setUserService(UserService userService) {
        this.userService = userService;
    }

}