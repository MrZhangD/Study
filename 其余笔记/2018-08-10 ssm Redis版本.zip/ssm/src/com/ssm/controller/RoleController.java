package com.ssm.controller;

import com.ssm.dto.DTO;
import com.ssm.dto.StatusCode;
import com.ssm.entity.Role;
import com.ssm.service.RoleService;
import com.ssm.vo.role.RoleAddVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

/**
 * 查询所有角色
 *
 */
@Controller
public class RoleController {

    @Autowired
    private RoleService roleService;

    // GET: 角色列表
    @RequestMapping(value = "/role/index", method = RequestMethod.GET)
    public String index(){
        return "role/index";
    }

    // GET: 新增角色页面
    @RequestMapping(value = "/role/add", method = RequestMethod.GET)
    public String add(){
        return "role/add";
    }

    // POST: 提交新增表单
    @RequestMapping(value = "/role/add", method = RequestMethod.POST)
    @ResponseBody
    public DTO add(RoleAddVO vo) {
        DTO dto = new DTO();

        // 1. 非空校验，只作为JSON错误的演示
        if (vo.getCode()==null || vo.getCode().trim().length()==0){
            dto.setCode(StatusCode.ROLE_ADD_NULL);
            dto.setMsg("新增失败，提供信息不完整");
            return dto;
        }

        // 1. 提取vo，并封装
        Role role = new Role();
        role.setCode(vo.getCode());
        role.setName(vo.getName());
        role.setDesc(vo.getDesc());

        // 2. 执行新增操作
        boolean result = roleService.add(role);
        if(result){
            dto.setCode(StatusCode.SUCCESS);
            dto.setMsg("新增成功");
            return dto;
        }

        dto.setCode(StatusCode.ERROR);
        dto.setMsg("新增失败");
        return dto;
    }


    // GET: 获取所有角色信息，JSON
    @CrossOrigin(origins = "*", maxAge = 3600)
    @RequestMapping(value = "/api/role", method = RequestMethod.GET, produces = {"application/json;charset=utf-8"})
    @ResponseBody
    public List<Role> list(){
        return roleService.getAll();
    }


    public RoleService getRoleService() {
        return roleService;
    }
    public void setRoleService(RoleService roleService) {
        this.roleService = roleService;
    }

}
