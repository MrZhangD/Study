package com.ssm.controller;

import com.alibaba.fastjson.JSON;
import com.ssm.dto.DTO;
import com.ssm.dto.StatusCode;
import com.ssm.entity.Role;
import com.ssm.entity.User;
import com.ssm.service.RoleService;
import com.ssm.service.UserService;
import com.ssm.util.Session;
import com.ssm.vo.user.UserAddVO;
import com.ssm.vo.user.UserLoginVO;
import com.ssm.vo.user.UserRegVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;
import sun.java2d.pipe.SolidTextRenderer;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;

@Controller
public class UserController {

    @Autowired
    public UserService userService;     // 注入用户业务

    @Autowired
    private RoleService roleService;    // 注入角色业务


    // GET: 查看用户列表
    @RequestMapping(value = "/user/index", method = RequestMethod.GET)
    public ModelAndView list(ModelAndView mv) {
        // 查询所有用户
        List<User> list = userService.getAll();

        // 将数据存入mv
        mv.addObject("data", list);

        // 指定显示的视图名称
        mv.setViewName("user/index");

        // 返回mv
        return mv;
    }


    // GET: 访问登录页面
    @RequestMapping(value = "/user/login", method = RequestMethod.GET)
    public String login() {
        return "user/login";
    }

    // POST: 提交登录表单。
    @RequestMapping(value = "/user/login", method = RequestMethod.POST)
    @CrossOrigin(origins = "*", maxAge = 3600)
    @ResponseBody
    public DTO login(HttpServletRequest request, UserLoginVO vo, HttpServletResponse response) {
        DTO dto = new DTO();

        // 1. 验证账号(邮箱)是否存在
        User user = userService.getByEmail(vo.getEmail());
        if (user == null) {
            dto.setCode(StatusCode.USER_LOGIN_EMAIL_NULL);
            dto.setMsg("登录失败，账号不存在。");
            return dto;
        }

        // 2. 登录验证(验证密码)
        if (!user.getPwd().equals(vo.getPwd())) {
            dto.setCode(StatusCode.USER_LOGIN_PWD_ERROR);
            dto.setMsg("登录失败，密码不正确。");
            return dto;
        }

        // 3. 登录成功
        // HttpSession session = request.getSession();
        // session.setAttribute("LoginUser", user);
        loginRedis(response, user);

        dto.setCode(StatusCode.SUCCESS);
        dto.setMsg("登录成功");
        return dto;
    }


    // GET: 访问注册页面
    @RequestMapping(value = "/user/reg", method = RequestMethod.GET)
    public String reg() {
        return "user/reg";
    }

    // POST: 提交注册表单
    @RequestMapping(value = "/user/reg", method = RequestMethod.POST)
    public ModelAndView reg(ModelAndView mv, UserRegVO vo) {
        // 1. 判断两次密码是否一致
        // 2. 根据 email 查询是否存在
        User existUser = userService.getByEmail(vo.getEmail());
        if (existUser != null) {
            mv.setViewName("user/reg");
            mv.addObject("msg", "账号已存在！");
            return mv;
        }

        // 3. 封装所需要的参数
        User user = new User();
        user.setEmail(vo.getEmail());
        user.setPwd(vo.getPwd1());

        // 4. 执行注册操作
        boolean result = userService.reg(user);

        // 5. 成功:重定向到登录页，失败:转发回注册页。
        if (result) {
            mv.setViewName("redirect:/user/login");
        } else {
            mv.setViewName("user/reg");
        }

        return mv;
    }


    // GET: 访问新增页面
    @RequestMapping(value = "/user/add", method = RequestMethod.GET)
    public String add() {
        return "user/add";
    }


    // POST: 提交添加表单
    @RequestMapping(value = "/user/add", method = RequestMethod.POST)
    @ResponseBody
    public DTO add(UserAddVO vo) {
        DTO dto = new DTO();

        // 1. 验证账号是否存在（按剧本来说，应该在页面验证）
        User result = userService.getByEmail(vo.getEmail());
        if (result != null) {
            dto.setCode(StatusCode.USER_ADD_EXIST); // 用常量表示数字，使其更直观
            dto.setMsg("目标用户已存在");              // 这个玩意儿叫"字面量"
            return dto;
        }

        // 2. 封装
        User user = new User();
        user.setEmail(vo.getEmail());
        user.setPwd(vo.getPwd());
        user.setName(vo.getName());
        user.setStatus(vo.isStatus());

        // 3. 执行添加操作
        boolean success = userService.reg(user);

        // 4. 如果注册失败，返回失败信息
        if (success == false){
            dto.setCode(StatusCode.ERROR);
            dto.setMsg("新增失败，请稍后再试");
            return dto;
        }

        // 5. 为当前用户分配角色
        User userAdd = userService.getByEmail(user.getEmail());
        int uid = userAdd.getId();  // 用户编号
        success = userService.updateRoles(uid, vo.getRoleIds());

        if (success == false){
            dto.setCode(StatusCode.ERROR);
            dto.setMsg("角色分配出错");
            return dto;
        }

        // 6. 如果注册成功，返回成功信息
        dto.setCode(StatusCode.SUCCESS);
        dto.setMsg("新增成功");
        return dto;
    }


    // GET: 访问退出链接
    @RequestMapping(value = "/user/logout", method = RequestMethod.GET)
    public String logout(HttpServletRequest request) {
        // 获取Session
        HttpSession session = request.getSession();

        // 移出登录标识
        session.removeAttribute("LoginUser");

        // 跳转到登录页面
        return "redirect:/user/login";
    }


    // GET: 修改用户状态

    /**
     * GET，修改用户状态。
     *
     * @param id 目标用户编号。
     * @return DTO。
     * 1000 成功
     * 2000 失败
     * 2001 用户不存在
     * 2002 用户存在，但更新出现问题
     */
    @RequestMapping(value = "/user/lock", method = RequestMethod.GET)
    @ResponseBody
    public DTO lock(int id) {
        DTO dto = new DTO();

        // 1. 查询目标用户信息
        User user = userService.getById(id);
        if (user == null) {
            dto.setCode(2001);
            dto.setMsg("用户不存在");
            return dto;
        }

        // 2. 修改用户状态
        boolean status = user.isStatus();   // 当前状态
        user.setStatus(!status);            // 改为相反

        // 3. 执行更新操作
        boolean result = userService.update(user);
        if (result == false) {
            dto.setCode(2002);
            dto.setMsg("用户存在，但更新失败");
            return dto;
        }

        dto.setCode(1000);
        dto.setMsg("更新成功");
        return dto;
    }


    // DELETE: /user/1001
    @RequestMapping(value = "/user/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public DTO del(@PathVariable("id") int id) {
        DTO dto = new DTO();

        boolean result = userService.delById(id);

        if (result) {
            dto.setCode(1000);
            dto.setMsg("删除成功！");
        } else {
            dto.setCode(2000);
            dto.setMsg("删除失败！");
        }

        return dto;
    }




    // 处理用户登录，使用上面的 set 方法
    public void loginRedis(HttpServletResponse response,User user){
        // 1. 生成GUID，作为key
        String uuid = UUID.randomUUID().toString();

        // 2. 将用户转为JSON并存入Redis
        Session.set(uuid, user);

        // 3. 将uuid存入cookie
        Cookie cookie = new Cookie("LoginUser", uuid);
        cookie.setMaxAge(60*60*24*7);
        cookie.setPath("/");
        response.addCookie(cookie);
    }




    // getter & setter
    public UserService getUserService() {
        return userService;
    }
    public void setUserService(UserService userService) {
        this.userService = userService;
    }
    public RoleService getRoleService() {
        return roleService;
    }
    public void setRoleService(RoleService roleService) {
        this.roleService = roleService;
    }
}
