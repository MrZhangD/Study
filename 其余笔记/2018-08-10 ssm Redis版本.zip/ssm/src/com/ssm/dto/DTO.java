package com.ssm.dto;

/**
 * Data Transfer Object
 * 数据传输对象，用于在控制器中统一对外返回的数据(JSON)。
 *
 * 全局通用的状态码：
 * 1000     操作成功
 * 2000     操作失败
 */
public class DTO {
    private int code;   // 状态码
    private String msg; // 消息
    private Object data;// 数据

    public int getCode() {
        return code;
    }
    public void setCode(int code) {
        this.code = code;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public Object getData() {
        return data;
    }
    public void setData(Object data) {
        this.data = data;
    }
}
