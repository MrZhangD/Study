package com.ssm.dto;

/**
 * 状态码。
 */
public class StatusCode {

    /* ====================
     * 全局统一
     * 1000 成功
     * 2000 失败
     * ====================
     */
    public static final int SUCCESS = 1000;
    public static final int ERROR = 2000;


    /* ====================
     * 登录相关
     * 2001 账户不存在
     * 2002 密码不正确
     * ====================
     */
    public static final int USER_LOGIN_EMAIL_NULL = 2001;
    public static final int USER_LOGIN_PWD_ERROR = 2002;


    /*
     * ====================
     * 用户添加相关
     * 2001 目标账户已存在
     * ====================
     */
    public static final int USER_ADD_EXIST = 2001;

    // 新增角色相关
    // 2001 提供信息不完整
    public static final int ROLE_ADD_NULL = 2001;

}
