package com.ssm.dao;

import com.ssm.entity.Role;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface RoleMapper {

    int add(Role role);

    Role selectById(@Param("id") int id);

    List<Role> selectByUserId(@Param("userId") int userId);

    List<Role> selectAll();

}
