package com.ssm.dao;

import com.ssm.entity.Role;
import com.ssm.entity.User;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * DAO接口声明，定义用户相关操作。
 */
public interface UserMapper {

    // 新增
    int add(User user);

    // 按编号删除
    int deleteById(@Param("id") int id);

    // 更新用户信息
    int update(User user);

    // 登录查询
    User login(User user);

    // 按编号查询
    User selectById(@Param("uid") int id);

    // 按邮箱查询
    User selectByEmail(@Param("email") String email);

    // 用于测试的查询所有
    List<User> selectAll();

    // 分配角色
    int updateRole(@Param("uid") int uid, @Param("roleIds") int[] roleIds);

    // 清空角色
    int clearRole(@Param("uid") int uid);

}
