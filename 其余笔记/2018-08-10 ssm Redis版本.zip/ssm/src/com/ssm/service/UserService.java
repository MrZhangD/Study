package com.ssm.service;

import com.ssm.entity.User;

import java.util.List;

/**
 * 业务接口，定义用户相关处理。
 */
public interface UserService {

    // 前台用户注册，返回:成功/失败。
    boolean reg(User user);

    // 按编号删除，返回:成功/失败。
    boolean delById(int id);

    // 更新用户信息
    boolean update(User user);

    // 前台用户登录，返回:null/用户信息。
    User login(User user);

    // 按编号查询用户信息
    User getById(int id);

    // 通过邮箱地址获取用户信息
    // 如果不存在，则返回null
    User getByEmail(String email);

    // 查询所有用户，返回:用户集合。
    List<User> getAll();

    // 更新用户角色
    boolean updateRoles(int uid, int[] roleIds);

}
