package com.ssm.service.impl;

import com.ssm.dao.UserMapper;
import com.ssm.entity.User;
import com.ssm.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    // Spring自动注入Mapper
    @Autowired
    private UserMapper userMapper;


    // 前台用户注册，返回:成功/失败。
    @Override
    public boolean reg(User user) {
        int count = userMapper.add(user);
        return count>0;
    }


    // 按编号删除，返回:成功/失败。
    @Override
    public boolean delById(int id) {
        // 1. 调用DAO，执行删除操作，获取受影响行数
        int count = userMapper.deleteById(id);

        // 2. 返回受影响行数是否大于0
        return count>0;
    }


    // 更新用户信息
    @Override
    public boolean update(User user) {
        return userMapper.update(user)>0;
    }


    // 前台用户登录，返回:null/用户信息。
    @Override
    public User login(User user) {
        return userMapper.login(user);
    }


    // 按编号查询用户信息
    @Override
    public User getById(int id) {
        return userMapper.selectById(id);
    }


    // 按邮箱地址查询，如果不存在，则返回null
    @Override
    public User getByEmail(String email) {
        return userMapper.selectByEmail(email);
    }


    // 查询所有用户信息，返回集合。
    @Override
    public List<User> getAll() {
        return userMapper.selectAll();
    }

    @Override
    public boolean updateRoles(int uid, int[] roleIds) {
        userMapper.clearRole(uid);

        if(roleIds==null || roleIds.length==0){
            return false;
        }

        return userMapper.updateRole(uid, roleIds)>0;
    }


    public UserMapper getUserMapper() {
        return userMapper;
    }
    public void setUserMapper(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

}
