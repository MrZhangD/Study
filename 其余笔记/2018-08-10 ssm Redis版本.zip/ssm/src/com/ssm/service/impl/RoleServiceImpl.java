package com.ssm.service.impl;

import com.ssm.dao.RoleMapper;
import com.ssm.entity.Role;
import com.ssm.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleServiceImpl implements RoleService {

    @Autowired
    private RoleMapper roleMapper;

    @Override
    public boolean add(Role role) {
        return roleMapper.add(role)>0;
    }

    @Override
    public Role getById(int id) {
        return roleMapper.selectById(id);
    }

    @Override
    public List<Role> getByUserId(int userId) {
        return roleMapper.selectByUserId(userId);
    }

    @Override
    public List<Role> getAll() {
        return roleMapper.selectAll();
    }

    public RoleMapper getRoleMapper() {
        return roleMapper;
    }
    public void setRoleMapper(RoleMapper roleMapper) {
        this.roleMapper = roleMapper;
    }

}
