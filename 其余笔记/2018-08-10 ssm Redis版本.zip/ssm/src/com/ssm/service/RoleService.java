package com.ssm.service;

import com.ssm.entity.Role;

import java.util.List;

public interface RoleService {

    boolean add(Role role);

    Role getById(int id);

    List<Role> getByUserId(int userId);

    List<Role> getAll();

}
