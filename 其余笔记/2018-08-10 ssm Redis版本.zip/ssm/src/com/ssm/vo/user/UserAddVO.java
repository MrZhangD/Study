package com.ssm.vo.user;

/**
 * 视图对象，用于封装"添加用户"所需要的参数。
 */
public class UserAddVO {
    private String email;
    private String pwd;
    private String name;
    private boolean status;
    private int[] roleIds;

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getPwd() {
        return pwd;
    }
    public void setPwd(String pwd) {
        this.pwd = pwd;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public boolean isStatus() {
        return status;
    }
    public void setStatus(boolean status) {
        this.status = status;
    }
    public int[] getRoleIds() {
        return roleIds;
    }
    public void setRoleIds(int[] roleIds) {
        this.roleIds = roleIds;
    }
}
