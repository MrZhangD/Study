package com.ssm.vo.user;

/**
 * 视图对象，封装用户注册时提交的参数。
 */
public class UserRegVO {
    private String email;
    private String pwd1;
    private String pwd2;

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getPwd1() {
        return pwd1;
    }
    public void setPwd1(String pwd1) {
        this.pwd1 = pwd1;
    }
    public String getPwd2() {
        return pwd2;
    }
    public void setPwd2(String pwd2) {
        this.pwd2 = pwd2;
    }
}
