package com.ssm.util;

import com.alibaba.fastjson.JSON;
import redis.clients.jedis.Jedis;


public class Session {

    private static Jedis jedis = null;

    static {
        jedis = new Jedis("127.0.0.1", 6379);
        jedis.auth("123456");
    }

    // 向 Redis 中存值
    public static void set(String key, Object value){
        String json = JSON.toJSONString(value);
        jedis.set(key, json);
    }

    // 从 Redis 中取值
    public static Object get(String key){
        return jedis.get(key);
    }

}
