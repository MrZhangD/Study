package com.ssm.filter;

import com.ssm.util.Session;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

// 拦截所有请求，没登录就不行
@WebFilter(urlPatterns = {"/user/*", "/role/*", "/home/*"})
public class LoginFilter implements Filter {

    // 初始化
    @Override
    public void init(FilterConfig filterConfig) throws ServletException { }

    // 处理
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest)servletRequest;
        HttpServletResponse response = (HttpServletResponse)servletResponse;

        String url = request.getRequestURI();

        // 如果访问的是登录或注册，直接放行
        if ( url.contains("/user/login") || url.contains("/user/reg") ){
            filterChain.doFilter(request, response);
            return;
        }

        // 从Cookie中获取用户标识
        String uuid = null;
        Cookie[] cookies = request.getCookies();    // 所有Cookie
        if(cookies!=null) {
            for (Cookie item : cookies) {
                if (item.getName().equals("LoginUser")) {
                    uuid = item.getValue();
                    break;
                }
            }
        }

        // 如果上面没有读取到uuid，证明cookie中压根没有
        // 反之，如果有，那么证明登录过，接着去Redis获取，看看还有效吗
        if (uuid != null){
            if(Session.get(uuid)!=null){
                filterChain.doFilter(request, response);    // 放行
                return;
            }
        }

        // 滚去登录
        response.sendRedirect("/user/login");
    }

    // 销毁
    @Override
    public void destroy() { }
}
