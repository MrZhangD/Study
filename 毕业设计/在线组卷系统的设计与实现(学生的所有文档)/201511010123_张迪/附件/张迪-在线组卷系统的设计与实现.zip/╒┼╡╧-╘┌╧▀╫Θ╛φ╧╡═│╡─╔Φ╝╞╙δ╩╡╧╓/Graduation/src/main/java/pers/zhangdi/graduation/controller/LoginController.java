package pers.zhangdi.graduation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import pers.zhangdi.graduation.service.impl.AdminServiceImpl;
import pers.zhangdi.graduation.service.impl.QuestionServiceImpl;
import pers.zhangdi.graduation.service.impl.TeacherServiceImpl;
import pers.zhangdi.graduation.vo.Admin;
import pers.zhangdi.graduation.vo.Question;
import pers.zhangdi.graduation.vo.Teacher;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
public class LoginController {

    @Autowired
    private AdminServiceImpl asl;
    @Autowired
    private TeacherServiceImpl tsl;
    @Autowired
    private QuestionServiceImpl qsl;

    @RequestMapping("/login")
    public String toLogin(){
        return "login";
    }

    @RequestMapping("/admin")
    public String toBackstage(){
        return "admin/backstage";
    }

    @RequestMapping("/test")
    public String toTeacher(Model model, int page, String sub, String type, HttpSession session, HttpServletRequest request){
        String keyWord = request.getParameter("keyWord");
        List<Question> list;
        int count = 0;
        int page_num = 0;
        if(keyWord != null && keyWord != ""){
            String searchSub = request.getParameter("searchSub");
            list = qsl.doSelectByKey(10*(page-1),keyWord,searchSub);
            count = qsl.doSelectCountByKey(keyWord,searchSub);
            model.addAttribute("searchSub",searchSub);
            model.addAttribute("keyWord",keyWord);
        }else{
            list = qsl.doSelectAllQuestionLimit(10*(page-1),sub,type);
            count = qsl.doSelectCount(sub,type);
            model.addAttribute("q_sub",sub);
        }

        if(count<=10){
            page_num = 1;
        }else if(count%10 == 0){
            page_num = count/10;
        }else{
            page_num = count/10+1;
        }

        if(session.getAttribute("now") != null&&session.getAttribute("now").toString().length()!=0){
            String now = (String)session.getAttribute("now");
            String c_now = "";
            String f_now = "";
            String b_now = "";
            String str[] = now.split(",");
            for (String s1 : str) {
                if(s1.startsWith("1"))
                    c_now = c_now+","+s1;
                else if(s1.startsWith("2"))
                    f_now = f_now+","+s1;
                else
                    b_now = b_now+","+s1;
            }

            if(c_now!="")
                model.addAttribute("c_now",c_now.substring(1));
            if(f_now!="")
                model.addAttribute("f_now",f_now.substring(1));
            if(b_now!="")
                model.addAttribute("b_now",b_now.substring(1));
        }

        model.addAttribute("type",type);
        model.addAttribute("page",page);
        model.addAttribute("page_num",page_num);
        model.addAttribute("list",list);
        model.addAttribute("count",count);
        return "teacher/index";
        /*将查询的mapper每次查询三条，测试并将分页按钮开发出来！*/
    }

    @RequestMapping("/check")
    public String toCheck(String id , String password , String option , Model model , HttpSession session){
        //管理员登录
        if("admin".equals(option)){
            Admin admin = asl.doSelectAdmin(id , password);
            if(admin != null){
                session.setAttribute("admin" , admin);
                return "redirect:/admin";
            }else{
                return "redirect:/login";
            }
        }else{          //教师登入
            Teacher teacher = tsl.doSelectTeacher(id , password);
            if(teacher != null){
                session.setAttribute("teacher",teacher);
                return "redirect:/test?page=1";
            }else {
                return "redirect:/login";
            }
        }
    }
}
