package pers.zhangdi.graduation.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pers.zhangdi.graduation.dao.TeacherMapper;
import pers.zhangdi.graduation.service.TeacherService;
import pers.zhangdi.graduation.vo.Teacher;

import java.util.List;

@Service
public class TeacherServiceImpl implements TeacherService {

    @Autowired
    private TeacherMapper teachermapper;

    public Teacher doSelectTeacher(String id, String password) {
        return teachermapper.findTeacher(id,password);
    }

    public Teacher doSelectTeacherById(String id) {
        return teachermapper.findTeacherById(id);
    }

    public List<Teacher> doSelectAllTeacher() {
        return teachermapper.findAllTeacher();
    }

    public boolean doInsertTeacher(Teacher teacher) {
        return teachermapper.addTeacher(teacher);
    }

    public boolean doDeleteTeacher(String id) {
        return teachermapper.deleteTeacher(id);
    }

    public boolean doUpdateInfo(Teacher teacher, String id) {
        return teachermapper.updateInfo(teacher,id);
    }
}
