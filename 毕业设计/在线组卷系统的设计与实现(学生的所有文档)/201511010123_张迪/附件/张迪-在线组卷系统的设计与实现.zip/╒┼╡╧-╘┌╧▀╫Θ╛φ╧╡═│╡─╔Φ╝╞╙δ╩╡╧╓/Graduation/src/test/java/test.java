import net.sourceforge.pinyin4j.PinyinHelper;
import sun.misc.BASE64Encoder;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;

public class test {
    public static void main(String[] args) {
        System.out.println(getPinYinNameWithoutTone("啊啊.JPG"));
    }

    public static String getPinYinNameWithoutTone(String chString) {
        char[] charArray = chString.toCharArray();
        StringBuilder pinyin = new StringBuilder();

        for(int i=0; i<charArray.length; i++){
            if(Character.toString(charArray[i]).matches("[\\u4E00-\\u9FA5]+")){
                String pinyinTemp = PinyinHelper.toHanyuPinyinStringArray(charArray[i])[0];
                pinyin.append(pinyinTemp.substring(0,pinyinTemp.length() - 1));
            }else{
                pinyin.append(charArray[i]);
            }
        }
        return pinyin.toString();
    }

    //获取线下图片base64
    public static String getImageBaseOffLine(String src) throws Exception {
        if (src == null || src == "") {
            return "";
        }
        File file = new File(src);
        if (!file.exists()) {
            return "";
        }
        InputStream in = null;
        byte[] data = null;
        try {
            in = new FileInputStream(file);
            data = new byte[in.available()];
            in.read(data);
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        BASE64Encoder encoder = new BASE64Encoder();
        return encoder.encode(data);
    }

    public static int getOccur(String src,String find){
        int o = 0;
        int index=-1;
        while((index=src.indexOf(find,index))>-1){
            ++index;
            ++o;
        }
        return o;
    }

    //获取线上图片的base64码
    public static String getImageBaseOnLine(String imgURL) {
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        try {
            // 创建URL
            URL url = new URL(imgURL);
            byte[] by = new byte[1024];
            // 创建链接
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            InputStream is = conn.getInputStream();
            // 将内容读取内存中
            int len = -1;
            while ((len = is.read(by)) != -1) {
                data.write(by, 0, len);
            }
            // 关闭流
            is.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // 对字节数组Base64编码
        return new String(Base64.getEncoder().encode(data.toByteArray()));
    }
}

