/*单击显示答案*/
function s(i){
    $("#answer" + i).toggle(500);
};
/*选择或移除试题时按钮的变化*/
function p(s,type,id){
    var c = $(s).attr("class");
    if(c == 'exam-exit add'){   /*选择该试题*/
        $(s).attr("class","exam-exit remove");
        $(s).text("-  移除");
        $(s).attr("onclick",($(s).attr("onclick").toString()).replace("add","del"));
        $(".basket-count span").text(parseInt($(".basket-count span").text())+1);

        if(type=="单选题"){
            if($("#choice").length == 0){
                $(".basket-list-ul").append("<li id=\"choice\">单选题：<span class='choice-count' style=\"color: blue;\">1</span>道\n" +
                    "<span onclick=\"remove('单选题',"+id+")\" style=\"margin-left: 120px; font-size: 18px;\"><b>X</b></span></li>");
            }else{
                $(".choice-count").text(parseInt($(".choice-count").text())+1);
                var pre = $($("#choice").find("span")[1]).attr("onclick").toString();
                var now = pre.substring(0,pre.lastIndexOf(')')) +","+ id + ")";
                $($("#choice").find("span")[1]).attr("onclick",now);
            }
        }else if(type=="填空题"){
            if($("#fill").length == 0){
                $(".basket-list-ul").append("<li id=\"fill\">填空题：<span class='fill-count' style=\"color: blue;\">1</span>道\n" +
                    "<span onclick=\"remove('填空题',"+id+")\" style=\"margin-left: 120px; font-size: 18px;\"><b>X</b></span></li>");
            }else{
                $(".fill-count").text(parseInt($(".fill-count").text())+1);
                var pre = $($("#fill").find("span")[1]).attr("onclick").toString();
                var now = pre.substring(0,pre.lastIndexOf(')')) +","+ id + ")";
                $($("#fill").find("span")[1]).attr("onclick",now);
            }
        }else{
            if($("#big").length == 0){
                $(".basket-list-ul").append("<li id=\"big\">大&emsp;题：<span class='big-count' style=\"color: blue;\">1</span>道\n" +
                    "<span onclick=\"remove('大题',"+id+")\" style=\"margin-left: 120px; font-size: 18px;\"><b>X</b></span></li>");
            }else{
                $(".big-count").text(parseInt($(".big-count").text())+1);
                var pre = $($("#big").find("span")[1]).attr("onclick").toString();
                var now = pre.substring(0,pre.lastIndexOf(')')) +","+ id + ")";
                $($("#big").find("span")[1]).attr("onclick",now);
            }
        }
    }
    else{                      /*移除该试题*/
        $(s).attr("class","exam-exit add");
        $(s).text("+  选择");
        $(s).attr("onclick",($(s).attr("onclick").toString()).replace("del","add"));
        $(".basket-count span").text(parseInt($(".basket-count span").text())-1);

        if(type=="单选题"){
            if($(".choice-count").text() == 1){
                $("#choice").remove();
            }else{
                $(".choice-count").text(parseInt($(".choice-count").text())-1);
                var pre = $($("#choice").find("span")[1]).attr("onclick").toString();
                var now = pre.replace(","+id ,"");
                $($("#choice").find("span")[1]).attr("onclick",now);
            }
        }else if(type=="填空题"){
            if($(".fill-count").text() == 1){
                $("#fill").remove();
            }else{
                $(".fill-count").text(parseInt($(".fill-count").text())-1);
                var pre = $($("#fill").find("span")[1]).attr("onclick").toString();
                var now = pre.replace(","+id ,"");
                $($("#fill").find("span")[1]).attr("onclick",now);
            }
        }else{
            if($(".big-count").text() == 1){
                $("#big").remove();
            }else{
                $(".big-count").text(parseInt($(".big-count").text())-1);
                var pre = $($("#big").find("span")[1]).attr("onclick").toString();
                var now = pre.replace(","+id ,"");
                $($("#big").find("span")[1]).attr("onclick",now);
            }
        }
    }
}
/*选择和移除时，试题蓝的变化*/
function remove() {
    var len = arguments.length;
    var type = arguments[0];
    if(confirm("您确定删除已选"+ type +"？！")){
        delAll(type);   //后台删除session
        for(var i = 1 ; i < len ; i++){         //当前页面按钮变换
            if($("#q-"+arguments[i] + " a").length != 0){
                $("#q-"+arguments[i] + " a").text("+ 选择");
                $("#q-"+arguments[i] + " a").addClass("add");
                $("#q-"+arguments[i] + " a").removeClass("remove");
            }
        }

        if(type == "单选题"){      //试题蓝里的对应试题显示，试题数量变化
            $(".basket-count span").text(parseInt($(".basket-count span").text())-parseInt($(".choice-count").text()));
            $("#choice").remove();
        }else if(type == "填空题"){
            $(".basket-count span").text(parseInt($(".basket-count span").text())-parseInt($(".fill-count").text()));
            $("#fill").remove();
        }else{
            $(".basket-count span").text(parseInt($(".basket-count span").text())-parseInt($(".big-count").text()));
            $("#big").remove();
        }
    }else{
        return false;
    }
}

/*选择试题时触发的ajax操作，在后台记录session*/
function addTest(s,type,id){
    $.ajax({
        type:'POST',
        url:'addTestSession',
        data:{id:id},
        success:function (data) {
            p(s,type,id);
            console.log("成功选择！");
        },
        error:function () {
            console.log("完蛋玩意儿！");
        }
    });
}
/*移除试题时触发的ajax操作*/
function delTest(s,type,id){
    $.ajax({
        type:'POST',
        url:'delTestSession',
        data:{id:id},
        success:function (data) {
            p(s,type,id);
            console.log("成功移除！");
        },
        error:function () {
            console.log("完蛋玩意儿！");
        }
    });
}
/*试题蓝删除某类试题时触发的ajax操作*/
function delAll(type){
    $.ajax({
        type:'POST',
        url:'delAllSession',
        data:{type:type},
        success:function (data) {
            console.log("成功从试题蓝中删除！");
        },
        error:function () {
            console.log("完蛋玩意儿！");
        }
    });
}