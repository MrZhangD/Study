package pers.zhangdi.graduation.service;

import pers.zhangdi.graduation.vo.Teacher;

import java.util.List;

public interface TeacherService {
    Teacher doSelectTeacher(String id, String password);//查(验证)
    Teacher doSelectTeacherById(String id); //根据ID查询用户
    List<Teacher> doSelectAllTeacher();//查询全部的用户
    boolean doInsertTeacher(Teacher teacher);//增
    boolean doDeleteTeacher(String id);//删
    boolean doUpdateInfo(Teacher teacher, String id);//改
}
