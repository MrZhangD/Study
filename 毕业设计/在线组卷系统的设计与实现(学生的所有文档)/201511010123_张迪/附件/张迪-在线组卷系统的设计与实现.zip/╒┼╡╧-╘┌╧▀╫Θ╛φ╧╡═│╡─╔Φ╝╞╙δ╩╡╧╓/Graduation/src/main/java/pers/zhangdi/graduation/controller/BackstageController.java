package pers.zhangdi.graduation.controller;

import net.sourceforge.pinyin4j.PinyinHelper;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import pers.zhangdi.graduation.service.impl.ExamPaperServiceImpl;
import pers.zhangdi.graduation.service.impl.QuestionServiceImpl;
import pers.zhangdi.graduation.service.impl.TeacherServiceImpl;
import pers.zhangdi.graduation.vo.ExamPaper;
import pers.zhangdi.graduation.vo.Question;
import pers.zhangdi.graduation.vo.Teacher;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
public class BackstageController {

    @Autowired
    private TeacherServiceImpl tsl;
    @Autowired
    private QuestionServiceImpl qsl;
    @Autowired
    private ExamPaperServiceImpl epsl;

/*===========================================================对题库的操作==================================================================*/
    //跳转到题库查看界面
    @RequestMapping("test_display")
    public String toTest_display(Model model,int page,HttpServletRequest request,HttpServletResponse response) throws UnsupportedEncodingException {
        request.setCharacterEncoding("utf-8");
        String keyWord = request.getParameter("keyWord");
        String type = request.getParameter("type");
        List<Question> list;
        int count = 0;
        int page_num = 0;
        if(keyWord != null && keyWord != ""){
            String searchSub = request.getParameter("searchSub");
            list = qsl.doSelectByKey(10*(page-1),keyWord,searchSub);
            count = qsl.doSelectCountByKey(keyWord,searchSub);
            model.addAttribute("searchSub",searchSub);
            model.addAttribute("keyWord",keyWord);
        }else{
            String sub = request.getParameter("sub");
            list = qsl.doSelectAllQuestionLimit(10*(page-1),sub,type);
            count = qsl.doSelectCount(sub,type);
            model.addAttribute("sub1",sub);
        }
        if(count <=10){
            page_num = 1;
        }else if(count%10 == 0){
            page_num = count/10;
        }else{
            page_num = count/10+1;
        }

        model.addAttribute("type1",type);
        model.addAttribute("page",page);
        model.addAttribute("page_num",page_num);
        model.addAttribute("list",list);
        model.addAttribute("count",count);
        return "admin/test_display";
    }

    /**********************搜索试题***********************/
    @RequestMapping({"q_search","fq_search"})
    public String toSearchQuestions(HttpServletRequest request,HttpServletResponse response,int page) throws UnsupportedEncodingException {
        response.setCharacterEncoding("utf-8");
        String searchSub = request.getParameter("searchSub");
        String keyWord = request.getParameter("keyWord");
        if(request.getRequestURI().contains("fq_search")){
            return "redirect:/test?keyWord="+ URLEncoder.encode(keyWord,"UTF-8")+"&searchSub="+URLEncoder.encode(searchSub,"UTF-8")+"&page=" + page;
        }else {
            return "redirect:/test_display?keyWord="+ URLEncoder.encode(keyWord,"UTF-8")+"&searchSub="+URLEncoder.encode(searchSub,"UTF-8")+"&page=" + page;
        }
    }

    //跳转到试题录入界面
    @RequestMapping("test_enter")
    public String toTest_entry(){
        return "admin/test_enter";
    }

    //跳转到试题修改界面
    @RequestMapping("test_alter")
    public String toTest_alter(Model model , String id , HttpServletRequest request , HttpSession session) throws UnsupportedEncodingException {
        Question q = qsl.doSelectQuestionById(id);
        String content = q.getContent();
        //题目主要内容
        String main = content.substring(content.indexOf("<div class=\"exam-q\">")+20,content.indexOf("</div>"));
        //如果是选择题，还需要把选项提取出来
        if(q.getType().equals("单选题")){
            String A;
            int begin;
            int end;

            begin=content.indexOf("<span class=\"op-answer\">")+24;
            end=content.indexOf("</span>",begin);
            A = content.substring(begin,end);
            model.addAttribute("A",A);

            for (int i = 0; i < 3; i++) {
                String answer;
                begin=content.indexOf("<span class=\"op-answer\">",begin)+24;
                end=content.indexOf("</span>",begin);
                answer = content.substring(begin,end);
                if(i==0){
                    model.addAttribute("B",answer);
                }else if(i==1){
                    model.addAttribute("C",answer);
                }else{
                    model.addAttribute("D",answer);
                }
            }
        }
        //如果是填空题也需要把选项提取出来
        if(q.getType().equals("填空题")){
            int begin;
            int end;
            String a = q.getAnswer();
            int num = getOccur(a,"【");
            List<String> answers = new ArrayList<String>();

            if(num==1){
                begin = a.indexOf("】")+1;
                end = a.length()-1;
                answers.add(a.substring(begin,end));
            }else{
                begin = a.indexOf("】")+1;
                end = a.indexOf("【",begin)-1;
                answers.add(a.substring(begin,end));
                for (int i = 1; i < num; i++) {
                    String answer;
                    begin = a.indexOf("】",begin)+1;
                    if(i==getOccur(a,"【")-1){
                        end = a.length()-1;
                    }else{
                        end = a.indexOf("【",begin)-1;
                    }
                    answer = a.substring(begin,end);
                    answers.add(answer);
                }
            }
            model.addAttribute("answers",answers);
        }

        request.setCharacterEncoding("utf-8");
        String msg = request.getParameter("msg");
        if(msg != null){
            if(msg.equals("success"))
                model.addAttribute("msg","修改成功！可以前往题库查看！");
            else
                model.addAttribute("msg","修改失败，请检查后重新修改");
        }
        session.setAttribute("pre",request.getHeader("referer"));
        model.addAttribute("main",main);
        model.addAttribute("q",q);
        return "admin/test_alter";
    }

    //试题录入操作
    @RequestMapping("addTest")
    public String toAddTest(Model model , HttpServletRequest request) throws UnsupportedEncodingException {
        request.setCharacterEncoding("utf-8");
        String q_type = request.getParameter("q_type");
        int score = Integer.parseInt(request.getParameter("score"));
        String sub = request.getParameter("sub_type");
        String content = "<div class=\"exam-q\">"+request.getParameter("editor")+"</div>";
        String answer = "";
        String id = "";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        //单选题处理（编号以1开头，共7位，内容需要处理）
        if("单选题".equals(q_type)){
            //id为 '1' + 当前系统时间如20190209123407
            id = id + "1" + sdf.format(new Date());
            //对试题内容的处理(将四个选项取出合入content中)
            String begin1 = "<span class=\"op\"><span class=\"op-item\">";
            String begin2 = "</span><span class=\"op-answer\">";
            String end = "</span></span>";
            String A = begin1 + "A、" + begin2 + request.getParameter("answer_A") + end;
            String B = begin1 + "B、" + begin2 + request.getParameter("answer_B") + end;
            String C = begin1 + "C、" + begin2 + request.getParameter("answer_C") + end;
            String D = begin1 + "D、" + begin2 + request.getParameter("answer_D") + end;
            String ops = "<div class=\"exam-o\">" + A + B + C + D + "</div>";
            content = content + ops;
            answer = request.getParameter("c_answer");
        }else if("填空题".equals(q_type)){
            //id为2000000+当前题目个数
            id = id + "2" + sdf.format(new Date());
            //从前台获取答案
            int fill_count = Integer.parseInt(request.getParameter("fill_count"));
            for (int i = 1; i <= fill_count; i++) {
                answer = answer + "【" + i + "】" + request.getParameter("answer"+i) + "；" ;
            }
        }else{
            //id为3000000+当前题目个数
            id = id + "3" + sdf.format(new Date());
            //
            answer = request.getParameter("editor1");
        }
        //试题向数据库中添加
        Question q = new Question(id,q_type,score,sub,content,answer);
        if(qsl.doInsertQuestion(q)){
            model.addAttribute("success","添加成功，可继续添加！");
            return "admin/test_enter";
        }else{
            model.addAttribute("fail","添加失败，请重新添加！");
            return "admin/test_enter";
        }
    }

    //试题修改操作(下一步是将修改操作的controller写出来，然后有个重置按钮的前端写好。)
    @RequestMapping("alterTest")
    public String toAlterTest(Model model,HttpServletRequest request,String id,HttpSession session) throws UnsupportedEncodingException {
        request.setCharacterEncoding("utf-8");
        String type = request.getParameter("type");
        int score = Integer.parseInt(request.getParameter("score"));
        String sub = request.getParameter("sub_type");
        String content = "<div class=\"exam-q\">"+request.getParameter("editor")+"</div>";
        String answer = "";

        if("单选题".equals(type)){
            //对试题内容的处理(将四个选项取出合入content中)
            String begin1 = "<span class=\"op\"><span class=\"op-item\">";
            String begin2 = "</span><span class=\"op-answer\">";
            String end = "</span></span>";
            String A = begin1 + "A、" + begin2 + request.getParameter("answer_A") + end;
            String B = begin1 + "B、" + begin2 + request.getParameter("answer_B") + end;
            String C = begin1 + "C、" + begin2 + request.getParameter("answer_C") + end;
            String D = begin1 + "D、" + begin2 + request.getParameter("answer_D") + end;
            String ops = "<div class=\"exam-o\">" + A + B + C + D + "</div>";
            content = content + ops;
            answer = request.getParameter("c_answer");
        }else if("填空题".equals(type)){
            //从前台获取答案
            int fill_count = Integer.parseInt(request.getParameter("fill_count"));
            for (int i = 1; i <= fill_count; i++) {
                answer = answer + "【" + i + "】" + request.getParameter("answer"+i) + "；" ;
            }
        }else{
            answer = request.getParameter("editor1");
        }

        //试题修改
        Question q = new Question(id,type,score,sub,content,answer);
        if(qsl.doUpdateQuestion(q)){
            String pre = session.getAttribute("pre").toString();
            session.removeAttribute("pre");
            if(pre.contains("testpaper")){
                String paperid = pre.substring(pre.indexOf("id")+3);
                return "redirect:/testpaper_display?id=" + paperid;
            }else
                return "redirect:/test_alter?id="+id + "&msg=" + "success";
        }else{
            return "redirect:/test_alter?id="+id + "&msg=" + "error";
        }
    }

    //试题删除操作
    @RequestMapping("delTest")
    @ResponseBody
    public void toDelTest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String id = request.getParameter("id");
        int count = Integer.parseInt(request.getParameter("count"))-1;
        Question question = qsl.doSelectQuestionById(id);
        String content = question.getContent() + question.getAnswer();
        if(qsl.doDeleteQuestion(id)){
            //有图片则将本地图片删除
            while(content.contains("<img")&&content.contains("img/q_img")){
                String realPath = request.getServletContext().getRealPath("/") + "WEB-INF\\img\\q_img\\";
                String imgRealPath = content.substring(content.indexOf("src=\"img/q_img/")+5);
                String imgName = imgRealPath.substring(10,imgRealPath.indexOf("\""));
                new File(realPath+imgName).delete();
                content = content.replaceFirst("src=\"img/q_img/","");
            }
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print(count);
            out.flush();
            out.close();
        }
    }

/*===========================================================对用户的操作==================================================================*/
    //跳转到用户查看界面
    @RequestMapping("user_display")
    public String toUser_display(Model model){
        List<Teacher> list = tsl.doSelectAllTeacher();
        model.addAttribute("list",list);
        return "admin/user_display";
    }

    //跳转到添加用户界面
    @RequestMapping("user_add")
    public String toUser_add(){
        return "admin/user_add";
    }

    //跳转到修改用户信息的界面
    @RequestMapping("user_alter")
    public String toUser_alter(Model model,String id){
        Teacher teacher = tsl.doSelectTeacherById(id);
        model.addAttribute("teacher",teacher);
        return "admin/user_alter";
    }

    //添加用户操作
    @RequestMapping("addUser")
    public String toAddUser(Model model, HttpServletRequest request)throws UnsupportedEncodingException {
        request.setCharacterEncoding("utf-8");
        String id = request.getParameter("user_id");
        String password = request.getParameter("user_pwd");
        String name = request.getParameter("user_name");
        String contact = request.getParameter("user_contact");

        Teacher teahcer = new Teacher(id,password,name,contact);
        if(tsl.doInsertTeacher(teahcer)){
            model.addAttribute("success","添加成功！可到用户列表查看。");
            return "admin/user_add";
        }else{
            return "admin/user_add";
        }

    }

    //修改用户操作
    @RequestMapping("alterUser")
    public String toAlterUser(Model model,String id,String password,String name,String contact){
        Teacher teacher = new Teacher(id,password,name,contact);
        if(tsl.doUpdateInfo(teacher,id)){
            return "redirect:/user_display";
        }else{
            return "redirect:/user_display";
        }
    }

    //删除用户操作
    @RequestMapping("delUser")
    public String toDelUser(String id){
        if (tsl.doDeleteTeacher(id)){
            return "redirect:/user_display";
        }else{
            return "redirect:/user_display";
        }
    }

/*===========================================================对试卷的操作==================================================================*/

    //跳转到试卷列表查看界面
    @RequestMapping("testpaper_list")
    public String toTestpaper_list(Model model){
        List<ExamPaper> list = epsl.doSelectAllExamPaper();
        model.addAttribute("list",list);
        return "admin/testpaper_list";
    }

    //跳转到查看一套试卷界面
    @RequestMapping({"testpaper_display","see-testpaper"})
    public String toTestpaper_display(Model model, String id, HttpServletRequest request){
        ExamPaper ep = epsl.doSelectExamPaper(id);
        List<String> q_choice = Arrays.asList(ep.getQChoice().split(","));
        List<String> q_fill = Arrays.asList(ep.getQFill().split(","));
        List<String> q_big = Arrays.asList(ep.getQBig().split(","));

        List<Question> c = new ArrayList<>();
        List<Question> f = new ArrayList<>();
        List<Question> b = new ArrayList<>();
        for (int i = 0; i < q_choice.size(); i++) {
            c.add(qsl.doSelectQuestionById(q_choice.get(i)));
        }
        for (int i = 0; i < q_fill.size(); i++) {
            f.add(qsl.doSelectQuestionById(q_fill.get(i)));
        }
        for (int i = 0; i < q_big.size(); i++) {
            b.add(qsl.doSelectQuestionById(q_big.get(i)));
        }

        //试卷信息
        model.addAttribute("paper",ep);
        //题目列表
        model.addAttribute("c_list",c);
        model.addAttribute("f_list",f);
        model.addAttribute("b_list",b);
        if(request.getRequestURI().contains("testpaper_display")){
            return "admin/testpaper_display";
        }else{
            return "teacher/testpaper_display";
        }
    }

    //试卷删除操作
    @RequestMapping({"delPaper","TeacherDelPaper"})
    public String toDelPaper(Model model,String id,HttpServletRequest request){
        if(request.getRequestURI().contains("TeacherDelPaper")){
            if (epsl.doDelExamPaper(id)){
                return "redirect:/testpapers";
            }else{
                return "redirect:/testpapers";
            }
        }else{
            if (epsl.doDelExamPaper(id)){
                return "redirect:/testpaper_list";
            }else{
                return "redirect:/testpaper_list";
            }
        }
    }
    /**
     * 上传Froala Editor 图片
     * @throws Exception
     */
    @RequestMapping("uploadImgEditor")
    @ResponseBody
    public void test(MultipartHttpServletRequest request,Model model,HttpServletResponse response) throws IOException {
        CommonsMultipartFile orginalFile = (CommonsMultipartFile) request.getFile("file");
        Map<String, String> map = new HashMap<>();
        //图片存储路径
        String savePath = request.getServletContext().getRealPath("/WEB-INF/img/q_img/");
        String url = "img/q_img/";      //一会编译器回显图片的url
        //如果上传的文件不为空
        if(!orginalFile.isEmpty()) {
            // 取得当前上传文件的名称
            String myFileName = orginalFile.getOriginalFilename();
            // 如果名称不为""，说明该文件存在，否则说明文件不存在。
            if (myFileName.trim() != "") {
                // 重命名上传后的文件
                SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
                String filename = sdf.format(new Date()) + "upload" + getPinYinNameWithoutTone(myFileName);
                // 上传到本地存储
                savePath = savePath + filename;
                File localFile = new File(savePath);
                try {
                    orginalFile.transferTo(localFile);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                url = url + filename;   //将url补充完整
            }
        }//重点注意：这里最好使用map存储，然后转换为json对象，这样前端接收到的
        // 才能识别，不然会出错！！！！！而使用json对象，需要引入json.jar包，不知道为什么
        //引入jar包后，还需要再将jar包放一份到tomcat中才行！！
        map.put("link",url);
        response.setContentType("json/html;charset=utf-8");
        PrintWriter out = response.getWriter();
        JSONObject json = new JSONObject(map);
        out.print(json);
        out.flush();
        out.close();
    }

    public static int getOccur(String src,String find){
        int o = 0;
        int index=-1;
        while((index=src.indexOf(find,index))>-1){
            ++index;
            ++o;
        }
        return o;
    }

    public static String getPinYinNameWithoutTone(String chString) {
        char[] charArray = chString.toCharArray();
        StringBuilder pinyin = new StringBuilder();

        for(int i=0; i<charArray.length; i++){
            if(Character.toString(charArray[i]).matches("[\\u4E00-\\u9FA5]+")){
                String pinyinTemp = PinyinHelper.toHanyuPinyinStringArray(charArray[i])[0];
                pinyin.append(pinyinTemp.substring(0,pinyinTemp.length() - 1));
            }else{
                pinyin.append(charArray[i]);
            }
        }
        return pinyin.toString();
    }
}
