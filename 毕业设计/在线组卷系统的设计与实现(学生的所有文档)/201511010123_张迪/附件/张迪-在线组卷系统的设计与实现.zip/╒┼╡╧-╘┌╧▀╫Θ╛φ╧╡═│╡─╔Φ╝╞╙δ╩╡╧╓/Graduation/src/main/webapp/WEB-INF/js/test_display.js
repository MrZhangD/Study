/*1、题库查看顶端导航的JS*/
$(".con-items a").click(function(){
    $(this).parent().find("a").removeClass("con-active");
    $(this).addClass("con-active");
});

/*2、题库查看的底部分页*/
$("#page-pre").click(function(){
    if($(".page-active").text() == 1){
        alert("已经是第一页了！");
    }else{
        var i = $(".page-active").text();
        $(".page-active").text(parseInt(i)-1);
    }
});
$("#page-next").click(function(){
    if($(".page-active").text() == $("#page_num").text()){
        alert("已经是最后一页了！");
    }else{
        var i = $(".page-active").text();
        $(".page-active").text(parseInt(i)+1);
    }
});
$("#page-jump").click(function(){
    var value = $("#num").val();
    var type = $("#now_type").val();
    var sub = $("#now_sub").val();
    var now_url = $("#now_url").val();

    if((/^(\+|-)?\d+$/.test(value))&&value>0&&value<=(parseInt($("#page_num").text()))){
        $(".page-active").text(value);
        var tohref;
        var pre;
        if(now_url == "teacher")
            pre='test?page=';
        else
            pre='test_display?page=';

        if(type == ''&&sub ==''){
            tohref = pre+value;
        }else if(type == ''&&sub != ''){
            tohref = pre+value + '&sub=' + sub;
        }else if(type != ''&&sub == ''){
            tohref = pre+value + '&type=' + type;
        }else {
            tohref = pre+value + '&type=' + type + '$sub=' + sub;
        }
        window.location.href = tohref;
    }else{
        alert("请输入正确的页数！");
    }
});
/*搜索框*/
$(function(){
    $(".select_box").click(function(event){
        event.stopPropagation();
        $(this).find(".option").toggle();
        $(this).parent().siblings().find(".option").hide();
    });
    $(document).click(function(event){
        var eo=$(event.target);
        if($(".select_box").is(":visible") && eo.attr("class")!="option" && !eo.parent(".option").length)
            $('.option').hide();
    });
    $(".option li").click(function(){
        var check_value=$(this).text();
        var zlValue = $('.option li:eq(1)').html();
        var bqValue = $('.option li:eq(2)').html();
        $(this).parent().siblings(".select_txt").text(check_value);
        $("#select_value").val(check_value);
    });
});