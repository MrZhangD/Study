/*后台左边导航*/
function pageClick(k) {
    $(k).parent().find("div").removeClass("active");
    $(k).addClass("active");
    $("#flTitle").text($(k).text());
    $(".content iframe").attr("src",$(k).attr("id"));
};


