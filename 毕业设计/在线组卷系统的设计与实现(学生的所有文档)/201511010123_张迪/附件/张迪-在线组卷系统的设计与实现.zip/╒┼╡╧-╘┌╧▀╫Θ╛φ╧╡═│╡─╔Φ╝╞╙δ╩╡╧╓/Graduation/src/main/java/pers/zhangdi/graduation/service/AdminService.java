package pers.zhangdi.graduation.service;

import pers.zhangdi.graduation.vo.Admin;

public interface AdminService {
    Admin doSelectAdmin(String id, String password);
}
