package pers.zhangdi.graduation.vo;


import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class Question {

  private String id;
  private String type;
  private long score;
  private String sub;
  private String content;
  private String answer;
  private Timestamp time;

  public Question() {
  }

  public Question(String id, String type, long score, String sub, String content, String answer) {
    this.id = id;
    this.type = type;
    this.score = score;
    this.sub = sub;
    this.content = content;
    this.answer = answer;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }


  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }


  public long getScore() {
    return score;
  }

  public void setScore(long score) {
    this.score = score;
  }


  public String getSub() {
    return sub;
  }

  public void setSub(String sub) {
    this.sub = sub;
  }


  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }


  public String getAnswer() {
    return answer;
  }

  public void setAnswer(String answer) {
    this.answer = answer;
  }

  @Override
  public String toString() {
    return "Question{" +
            "id='" + id + '\'' +
            ", type='" + type + '\'' +
            ", score=" + score +
            ", sub='" + sub + '\'' +
            ", content='" + content + '\'' +
            ", answer='" + answer + '\'' +
            ", time=" + time +
            '}';
  }

  public String getTime() {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    return sdf.format(time);
  }

  public void setTime(Timestamp time) {
    this.time = time;
  }
}
