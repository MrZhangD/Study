package pers.zhangdi.graduation.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pers.zhangdi.graduation.dao.AdminMapper;
import pers.zhangdi.graduation.service.AdminService;
import pers.zhangdi.graduation.vo.Admin;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private AdminMapper adminmapper;
    //根据id和password查询管理员
    public Admin doSelectAdmin(String id, String password) {
        return adminmapper.findAdmin(id, password);
    }
}
