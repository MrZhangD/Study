package pers.zhangdi.graduation.interceptor;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class BackLoginInterceptor implements HandlerInterceptor {

    //Controller之前进行拦截  后台登陆拦截
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object o) throws Exception {
        if(request.getSession().getAttribute("admin") != null){
            return true;
        }else{
            response.sendRedirect("/login");
            return false;
        }
    }

    //Controller之后进行拦截
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) throws Exception {

    }

    //请求处理完毕之后，页面输出给浏览器之前进行拦截
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) throws Exception {

    }
}
