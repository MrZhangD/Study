package pers.zhangdi.graduation.dao;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import pers.zhangdi.graduation.vo.Teacher;

import java.util.List;

@Repository
public interface TeacherMapper {
    //查找(验证)
    Teacher findTeacher(@Param("id") String id, @Param("password") String password);
    //根据id查找用户
    Teacher findTeacherById(@Param("id") String id);
    //查看所有的教师
    List<Teacher> findAllTeacher();
    //增加教师用户
    boolean addTeacher(@Param("teacher") Teacher teacher);
    //删除教师用户
    boolean deleteTeacher(@Param("id") String id);
    //修改用户信息
    boolean updateInfo(@Param("teacher") Teacher teacher, @Param("id") String id);
}
