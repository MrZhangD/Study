function s(i){
    $("#b-answer" + i).toggle(500);
};
$(".title input").change(function () {
    var info = $(this).val();
    var id = $(this).attr("id");
    $.ajax({
        type:'POST',
        url:'test-title',
        data:{info:info,id:id},
        success:function (data) {
            console.log("成功修改试卷信息！");
        },
        error:function () {
            console.log("完蛋玩意儿！");
        }
    });
});
function keep(){
    var title = $("#test-title").val();
    var sub = $("#test-sub").val();
    var grade = $("#test-grade").val();
    if(title==""||sub==""||grade==""){
        alert("请将试卷信息填写完整");
    }else{
        if(confirm("确认保存该套试卷？！")){
            $.ajax({
                type:'POST',
                url:'keeptest',
                success:function (data) {
                    $(".list").empty();
                    $(".keep").remove();
                    $(".list").css({"height":"578px","text-align":"center"});
                    $(".list").html("<h1 style=\"margin-top: 200px;\">哦吼~保存成功！可前往试卷库查看或修改试卷！</h1>");
                    console.log("成功保存一套试卷！");
                },
                error:function () {
                    console.log("完蛋玩意儿！");
                }
            });
        }
    }
};
/*
$(".q-list li").mouseenter(function(){
   $(this).children(".hover-del").slideDown(100);
});
$(".q-list li").mouseleave(function(){
    $(this).children(".hover-del").slideUp(100);
})*/
