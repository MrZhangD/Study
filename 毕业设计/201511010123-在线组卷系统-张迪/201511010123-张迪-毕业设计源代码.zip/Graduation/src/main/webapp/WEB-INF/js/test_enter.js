/*3、试题的录入中的JS*/
$(function(){
    /*$('#editor').editable({inlineMode: false, alwaysBlank: true});*/
    $('#editor').editable({
        inlineMode: false,
        alwaysBlank: true,
        imageUploadURL: "uploadImgEditor"
    });
    $('#editor1').editable({
        inlineMode: false,
        alwaysBlank: true,
        imageUploadURL: "uploadImgEditor"
    })
});

/*选择题型时试题录入格式的变化*/
$("#select-qtype").change(function(){
    var s = $(this).children('option:selected').val();
    if(s == "单选题"){
        $(".blanks-q").fadeOut(500);
        $(".big-q").fadeOut(500);
        $(".choice-q").delay(500).fadeIn();
    }else if(s == "填空题"){
        $(".choice-q").fadeOut(500);
        $(".big-q").fadeOut(500);
        $(".blanks-q").delay(500).fadeIn();
    }else if(s == "大题"){
        $(".choice-q").fadeOut(500);
        $(".blanks-q").fadeOut(500);
        $(".big-q").delay(500).fadeIn();
    }
});
/*增加填空*/
$("#add-blank").click(function(){
    var i = $(".blanks-q").length;
    $(this).parent().parent().before("<tr class=\"blanks-q\">\n" +
        "<td><label class=\"td_label\">答案【"+i+"】</label></td>\n" +
        "<td colspan=\"5\"><textarea type=\"text\" class=\"book_input03\" name =\"answer"+i+"\" required autocomplete=\"off\"></textarea></td>\n" +
        "</tr>");
    $("#fill_count").attr("value",parseInt($("#fill_count").val())+1);
});
/*删除填空*/
$("#del-blank").click(function () {
    var i = $(".blanks-q").length;
    if(i < 3){
        alert("不能删除了！只剩一个了！");
    }else{
        $(this).parent().parent().prev().remove();
        $("#fill_count").attr("value",parseInt($("#fill_count").val())-1);
    }
});