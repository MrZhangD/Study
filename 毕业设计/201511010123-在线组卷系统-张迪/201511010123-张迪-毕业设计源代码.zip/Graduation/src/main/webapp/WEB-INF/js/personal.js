$("#pwd-div").click(function () {
    $(".white_content").html("<form method='post' action='change_pwd' id='pwd_form'><div class=\"pwd-box\">\n" +
        "<p><label style=\"color:#000000;\">原密码：</label><input type=\"password\" onfocus='t(this)' id=\"old\" name=\"old-pwd\"  required autocomplete=\"off\" ></p>\n" +
        "<p><label style=\"color:#000000;\">新密码：</label><input type=\"password\" onfocus='t(this)' id=\"new\" name=\"new-pwd\" required autocomplete=\"off\"></p>\n" +
        "<p><label style=\"color:#000000;\">再次输入：</label><input type=\"password\" onfocus='t(this)' id=\"again\" name=\"again-pwd\" required autocomplete=\"off\"></p>\n" +
        "</div><div style=\"text-align: center;margin-top: 50px;\">\n" +
        "    <button type='button' class=\"btn btn-primary\" onclick=\"change_pwd()\">修改</button>\n" +
        "<button type='button' class=\"btn btn-primary\" onclick=\"document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'\">\n" +
        "取消</button>" +
        "</div></form>");
    $("#light").slideDown(200);
    document.getElementById('fade').style.display='block';
});

function change_pwd(){
    var old = $("#old").val();
    var new_pwd = $("#new").val();
    var again = $("#again").val();
    if(old != ''&& new_pwd != '' && again != ''){
        if(new_pwd == again){
            if(confirm("确认修改密码么？！修改之后需要重新登录！")){
                $.ajax({
                    type:'POST',
                    url:'checkOld',
                    data:{old:old},
                    success:function (data) {
                        var json = JSON.parse(data);
                        if(json.res == '不可以'){
                            alert("原密码不正确");
                        }else {
                            $('#pwd_form').submit();
                        }
                    },
                    error:function () {
                        console.log("完蛋玩意儿！");
                    }
                });
            }
        }else{
            alert("两次输入密码不一致！");
            return false;
        }
    }else{
        if(old == ''){
            $('#old').css("border","1px solid red");
        }
        if(new_pwd == ''){
            $('#new').css("border","1px solid red");
        }
        if(again == ''){
            $('#again').css("border","1px solid red");
        }
    }
};

function  t(t) {
    $(t).css("border","1px solid #dcdcdc");
};

function cancle(){
    if(confirm('确认注销么？')){
        $.ajax({
            type:'POST',
            url:'cancle',
            success:function (data) {
                location.reload();
            },
            error:function () {
                alert("注销失败");
                console.log("完蛋玩意儿！");
            }
        });
    }else{
        return false;
    }
}