package pers.zhangdi.graduation.dao;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import pers.zhangdi.graduation.vo.Admin;

@Repository
public interface AdminMapper {
    Admin findAdmin(@Param("id") String id, @Param("password") String password);
}
