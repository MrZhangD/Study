package pers.zhangdi.graduation.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pers.zhangdi.graduation.dao.ExamPaperMapper;
import pers.zhangdi.graduation.service.ExamPaperService;
import pers.zhangdi.graduation.vo.ExamPaper;

import java.util.List;

@Service
public class ExamPaperServiceImpl implements ExamPaperService {

    @Autowired
    private ExamPaperMapper exampapermapper;

    @Override
    public boolean doInsertExamPaper(ExamPaper exampaper) {
        return exampapermapper.addExamPaper(exampaper);
    }

    @Override
    public boolean doDelExamPaper(String id) {
        return exampapermapper.delExamPaper(id);
    }

    @Override
    public List<ExamPaper> doSelectAllExamPaper() {
        return exampapermapper.findAllExamPaper();
    }

    @Override
    public ExamPaper doSelectExamPaper(String id) {
        return exampapermapper.findExamPaper(id);
    }

    @Override
    public List<ExamPaper> doSelectExamPaperById(String authorid) {
        return exampapermapper.findExamPaperById(authorid);
    }
}
