package pers.zhangdi.graduation.vo;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class ExamPaper {

  private String title;
  private String id;
  private String author;
  private String author_id;
  private String sub;
  private String grade;
  private Timestamp time;
  private String q_choice;
  private String q_fill;
  private String q_big;


  public ExamPaper(String title, String id, String author, String author_id, String sub, String grade, String q_choice, String q_fill, String q_big) {
    this.title = title;
    this.id = id;
    this.author = author;
    this.author_id = author_id;
    this.sub = sub;
    this.grade = grade;
    this.q_choice = q_choice;
    this.q_fill = q_fill;
    this.q_big = q_big;
  }

  @Override
  public String toString() {
    return "ExamPaper{" +
            "title='" + title + '\'' +
            ", id='" + id + '\'' +
            ", author='" + author + '\'' +
            ", author_id='" + author_id + '\'' +
            ", sub='" + sub + '\'' +
            ", grade='" + grade + '\'' +
            ", time=" + time +
            ", q_choice='" + q_choice + '\'' +
            ", q_fill='" + q_fill + '\'' +
            ", q_big='" + q_big + '\'' +
            '}';
  }

  public ExamPaper() {
    }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getAuthorId() {
    return author_id;
  }

  public void setAuthorId(String author_id) {
    this.author_id = author_id;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }


  public String getAuthor() {
    return author;
  }

  public void setAuthor(String author) {
    this.author = author;
  }


  public String getSub() {
    return sub;
  }

  public void setSub(String sub) {
    this.sub = sub;
  }


  public String getGrade() {
    return grade;
  }

  public void setGrade(String grade) {
    this.grade = grade;
  }


  public String getTime() {
      SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
      return sdf.format(time);
  }

  public void setTime(Timestamp time) {
    this.time = time;
  }


  public String getQChoice() {
    return q_choice;
  }

  public void setQChoice(String q_choice) {
    this.q_choice = q_choice;
  }


  public String getQFill() {
    return q_fill;
  }

  public void setQFill(String q_fill) {
    this.q_fill = q_fill;
  }


  public String getQBig() {
    return q_big;
  }

  public void setQBig(String q_big) {
    this.q_big = q_big;
  }

}
