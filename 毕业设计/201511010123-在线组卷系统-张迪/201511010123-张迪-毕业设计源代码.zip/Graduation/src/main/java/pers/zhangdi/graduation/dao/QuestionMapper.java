package pers.zhangdi.graduation.dao;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import pers.zhangdi.graduation.vo.Question;

import java.util.List;

@Repository
public interface QuestionMapper {
    //增
    boolean addQuestion(@Param("question") Question question);
    //删
    boolean deleteQuestion(@Param("id") String id);
    //改
    boolean updateQuestion(@Param("question") Question question);
    //根据id查询
    Question findQuestionById(@Param("id") String id);
    //一次查询10道题目
    List<Question> findAllQuestionLimit(@Param("begin") int begin, @Param("sub") String sub, @Param("type") String type);
    //查询数量
    int findCount(@Param("sub") String sub, @Param("type") String type);
    //根据type查询该type所有题目的id
    List<String> findIdByType(@Param("type") String type, @Param("sub") String sub);
    //根据关键词和科目查询题目id
    List<Question> findIdByKey(@Param("begin") int begin, @Param("key") String key, @Param("sub") String sub);
    //查询数量根据关键词和科目
    int findCountByKey(@Param("key") String key, @Param("sub") String sub);
}
