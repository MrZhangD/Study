package pers.zhangdi.graduation.service;

import pers.zhangdi.graduation.vo.Question;

import java.util.List;

public interface QuestionService {
    //增
    boolean doInsertQuestion(Question question);
    //删
    boolean doDeleteQuestion(String id);
    //改
    boolean doUpdateQuestion(Question question);
    //根据ID查询
    Question doSelectQuestionById(String id);
    //一次查询3道题目
    List<Question> doSelectAllQuestionLimit(int begin, String sub, String type);
    //查询数量
    int doSelectCount(String sub, String type);
    //根据Type查询题目id
    List<String> doSelectIdByType(String type, String sub);
    //
    List<Question> doSelectByKey(int page, String key, String sub);
    //
    int doSelectCountByKey(String key, String sub);
}
