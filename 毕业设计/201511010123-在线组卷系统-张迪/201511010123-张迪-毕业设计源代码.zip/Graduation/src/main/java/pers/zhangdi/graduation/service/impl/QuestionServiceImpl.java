package pers.zhangdi.graduation.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pers.zhangdi.graduation.dao.QuestionMapper;
import pers.zhangdi.graduation.service.QuestionService;
import pers.zhangdi.graduation.vo.Question;

import java.util.List;

@Service
public class QuestionServiceImpl implements QuestionService {

    @Autowired
    private QuestionMapper questionmapper;

    public boolean doInsertQuestion(Question question) {
        return questionmapper.addQuestion(question);
    }

    public boolean doDeleteQuestion(String id) {
        return questionmapper.deleteQuestion(id);
    }

    public boolean doUpdateQuestion(Question question) {
        return questionmapper.updateQuestion(question);
    }

    public Question doSelectQuestionById(String id) {
        return questionmapper.findQuestionById(id);
    }

    public List<Question> doSelectAllQuestionLimit(int begin , String sub , String type) {
        return questionmapper.findAllQuestionLimit(begin,sub,type);
    }

    public int doSelectCount(String sub , String type) {
        return questionmapper.findCount(sub,type);
    }

    @Override
    public List<String> doSelectIdByType(String type,String sub) {
        return questionmapper.findIdByType(type,sub);
    }

    @Override
    public List<Question> doSelectByKey(int page , String key, String sub) {
        return questionmapper.findIdByKey(page,key,sub);
    }

    @Override
    public int doSelectCountByKey(String key, String sub) {
        return questionmapper.findCountByKey(key,sub);
    }
}
