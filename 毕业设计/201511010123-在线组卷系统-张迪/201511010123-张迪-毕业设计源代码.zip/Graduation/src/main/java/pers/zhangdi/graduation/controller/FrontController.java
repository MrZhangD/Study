package pers.zhangdi.graduation.controller;

import freemarker.template.Configuration;
import freemarker.template.Template;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import pers.zhangdi.graduation.service.impl.ExamPaperServiceImpl;
import pers.zhangdi.graduation.service.impl.QuestionServiceImpl;
import pers.zhangdi.graduation.service.impl.TeacherServiceImpl;
import pers.zhangdi.graduation.vo.ExamPaper;
import pers.zhangdi.graduation.vo.Question;
import pers.zhangdi.graduation.vo.Teacher;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
public class FrontController {
    @Autowired
    private TeacherServiceImpl tsl;
    @Autowired
    private QuestionServiceImpl qsl;
    @Autowired
    private ExamPaperServiceImpl epsl;

    //前台选择试题时触发的ajax操作
    @RequestMapping("addTestSession")
    @ResponseBody
    public void addTestSession(HttpServletRequest request, HttpSession session){
        String id = request.getParameter("id");
        Set<String> nowList;
        if(session.getAttribute("nowList") == null){
            nowList = new TreeSet<>();
        }else{
            nowList = (TreeSet)session.getAttribute("nowList");
        }
        nowList.add(id);
        //统计现在已选择的各种题型的数量以及ID
        int c_num,f_num,b_num;
        c_num = getNum("c_num",session);
        f_num = getNum("f_num",session);
        b_num = getNum("b_num",session);
        if(id.startsWith("1")){
            c_num++;
        }else if(id.startsWith("2")){
            f_num++;
        }else{
            b_num++;
        }

        session.setAttribute("c_num",c_num);
        session.setAttribute("f_num",f_num);
        session.setAttribute("b_num",b_num);
        session.setAttribute("now",nowList.toString().substring(1,nowList.toString().length()-1).replaceAll(" ",""));
        session.setAttribute("nowList",nowList);
    }

    //前台移除试题时触发的ajax操作
    @RequestMapping("delTestSession")
    @ResponseBody
    public void delTestSession(HttpServletRequest  request , HttpSession session){
        String id = request.getParameter("id");
        Set<String> nowList = (TreeSet)session.getAttribute("nowList");
        nowList.remove(id);
        if(id.startsWith("1")){
            session.setAttribute("c_num",(int)session.getAttribute("c_num")-1);
        }else if(id.startsWith("2")){
            session.setAttribute("f_num",(int)session.getAttribute("f_num")-1);
        }else{
            session.setAttribute("b_num",(int)session.getAttribute("b_num")-1);
        }
        session.setAttribute("now",nowList.toString().substring(1,nowList.toString().length()-1).replaceAll(" ",""));
        if(nowList.size() == 0){
            session.setAttribute("nowList",null);
            reomveTestInfo(session);
        }
        else
            session.setAttribute("nowList",nowList);
    }

    //从试题蓝中删除某类试题触发的ajax操作
    @RequestMapping("delAllSession")
    @ResponseBody
    public void delAllSession(HttpServletRequest  request , HttpSession session){
        String type = request.getParameter("type");
        Set<String> nowList = (TreeSet)session.getAttribute("nowList");
        int begin = 0;
        int end = 0;
        int c_num = (int)session.getAttribute("c_num");
        int f_num = (int)session.getAttribute("f_num");
        int b_num = (int)session.getAttribute("b_num");
        if(type.equals("单选题")){
            Iterator<String> it = nowList.iterator();
            for(int i = 0 ; i < c_num ; i++){
                it.next();
                it.remove();
            }
            session.setAttribute("c_num",0);
        }else if(type.equals("填空题")){
            Iterator<String> it = nowList.iterator();
            for(int i = 0 ; i < f_num+c_num ; i++){
                it.next();
                if(i>=c_num)
                    it.remove();
            }
            session.setAttribute("f_num",0);
        }else{
            Iterator<String> it = nowList.iterator();
            for(int i = 0 ; i < f_num+c_num+b_num ; i++){
                it.next();
                if(i>=c_num+f_num) {
                    it.remove();
                }
            }
            session.setAttribute("b_num",0);
        }
        session.setAttribute("now",nowList.toString().substring(1,nowList.toString().length()-1).replaceAll(" ",""));
        if(nowList.size() == 0){
            session.setAttribute("nowList",null);
            reomveTestInfo(session);
        }
        else
            session.setAttribute("nowList",nowList);
    }

    //将试卷标题，年级，科目统统从session中移除
    public void reomveTestInfo(HttpSession session){
        if(session.getAttribute("title") != null)
            session.removeAttribute("title");
        if(session.getAttribute("sub") != null)
            session.removeAttribute("sub");
        if(session.getAttribute("grade") != null)
            session.removeAttribute("grade");
    }

    //从session中获取当前已选题目的数量
    public int getNum(String type,HttpSession session){
        int num;
        if(session.getAttribute(type) == null){
            num = 0;
        }else{
            num = (int)session.getAttribute(type);
        }
        return num;
    }

    //跳转到nowtest.jsp，当前试卷的页面
    @RequestMapping("nowTest")
    public String toNowTest(Model model,HttpSession session){
        Set<String> nowList;
        List<Question> c_list = new ArrayList<>();
        List<Question> f_list = new ArrayList<>();
        List<Question> b_list = new ArrayList<>();
        if(session.getAttribute("nowList") == null){
            String msg = "你还没有选择任何试题...";
            model.addAttribute("msg",msg);
        }else{
            nowList = (TreeSet)session.getAttribute("nowList");
            for (String s : nowList) {
                if(s.startsWith("1")){
                    c_list.add(qsl.doSelectQuestionById(s));
                }else if(s.startsWith("2")){
                    f_list.add(qsl.doSelectQuestionById(s));
                }else{
                    b_list.add(qsl.doSelectQuestionById(s));
                }
            }
        }
        model.addAttribute("c_list",c_list);
        model.addAttribute("f_list",f_list);
        model.addAttribute("b_list",b_list);
        return "teacher/nowtest";
    }

    //修改试卷标题触发的ajax
    @RequestMapping("test-title")
    @ResponseBody
    public void toChangeInfo(HttpSession session,HttpServletRequest request){
        String info = request.getParameter("info");
        String id = request.getParameter("id");
        if(id.equals("test-title")){
            session.setAttribute("title",info);
        }else if(id.equals("test-grade")){
            session.setAttribute("grade",info);
        }else{
            session.setAttribute("sub",info);
        }
    }

    //保存一套试卷操作，记得将session中的信息清除
    @RequestMapping("keeptest")
    @ResponseBody
    public void toKeepTest(HttpSession session){
        //首先将session中的试卷信息取出来
        String title = (String)session.getAttribute("title");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        Teacher teacher = (Teacher)session.getAttribute("teacher");
        String author = teacher.getName();
        String author_id = teacher.getId();
        String id = author_id + sdf.format(new Date());
        String sub = (String)session.getAttribute("sub");
        String grade = (String)session.getAttribute("grade");
        String now = (String)session.getAttribute("now");
        String q_choice = "",q_fill = "",q_big = "";
        String str[] = now.split(",");
        for (String s1 : str) {
            if(s1.startsWith("1"))
                q_choice = q_choice+","+s1;
            else if(s1.startsWith("2"))
                q_fill = q_fill+","+s1;
            else
                q_big = q_big+","+s1;
        }
        if(q_choice==""){
            q_choice="00";
        }if(q_fill==""){
            q_fill="00";
        }if(q_big==""){
            q_big="00";
        }
        ExamPaper exampaper = new ExamPaper(title,id,author,author_id,sub,
                grade,q_choice.substring(1),q_fill.substring(1),q_big.substring(1));
        if(epsl.doInsertExamPaper(exampaper)){
            //删除session中的试卷的信息
            session.removeAttribute("title");
            session.removeAttribute("sub");
            session.removeAttribute("grade");
            session.removeAttribute("c_num");
            session.removeAttribute("f_num");
            session.removeAttribute("b_num");
            session.removeAttribute("nowList");
            session.removeAttribute("now");
        }
    }

    //跳转到个人试卷库
    @RequestMapping("testpapers")
    public String toTestPapers(Model model,HttpSession session){
        Teacher teacher = (Teacher) session.getAttribute("teacher");
        String author_id = teacher.getId();
        List<ExamPaper> list = epsl.doSelectExamPaperById(author_id);
        model.addAttribute("list",list);
        return "teacher/testpapers";
    }

    //重新编辑，跳转页面，并将该套试卷的信息保存在当前session中
    @RequestMapping("reedit")
    public String toReedit(Model model,String id ,HttpSession session){
        ExamPaper exampaper = epsl.doSelectExamPaper(id);
        session.setAttribute("title",exampaper.getTitle());
        session.setAttribute("sub",exampaper.getSub());
        session.setAttribute("grade",exampaper.getGrade());
        Set<String> nowList = new TreeSet<>();
        int c_num=0,f_num=0,b_num=0;


        if(!exampaper.getQChoice().equals("0")){
            String q_choice[] = exampaper.getQChoice().split(",");
            c_num = q_choice.length;
            for (String s : q_choice) {
                nowList.add(s);
            }
        }

        if(!exampaper.getQFill().equals("0")){
            String q_fill[] = exampaper.getQFill().split(",");
            f_num = q_fill.length;
            for (String s : q_fill) {
                nowList.add(s);
            }
        }

        if(!exampaper.getQBig().equals("0")){
            String q_big[] = exampaper.getQBig().split(",");
            b_num = q_big.length;
            for (String s : q_big) {
                nowList.add(s);
            }
        }
        session.setAttribute("c_num",c_num);
        session.setAttribute("f_num",f_num);
        session.setAttribute("b_num",b_num);
        session.setAttribute("nowList",nowList);
        session.setAttribute("now",nowList.toString().substring(1,nowList.toString().length()-1).replaceAll(" ",""));
        return "redirect:/nowTest";
    }

    //跳转到个人资料页面
    @RequestMapping("personal")
    public String toPersonal(Model model,String id,HttpSession session){
        return "teacher/personal";
    }

    //修改个人信息操作并刷新页面
    @RequestMapping("change_per")
    public String toChangePer(HttpSession session,HttpServletRequest request){
        String name = request.getParameter("name");
        String contact = request.getParameter("contact");
        Teacher teacher = (Teacher) session.getAttribute("teacher");
        String id = teacher.getId();
        teacher.setName(name);
        teacher.setContact(contact);
        tsl.doUpdateInfo(teacher,id);

        session.removeAttribute("teacher");
        session.setAttribute("teacher",teacher);
        return "redirect:/personal";
    }

    //修改密码操作
    @RequestMapping("change_pwd")
    public String toChange_pwd(HttpSession session,HttpServletRequest request){
        Teacher teacher = (Teacher)session.getAttribute("teacher");
        String newpwd = request.getParameter("new-pwd");
        teacher.setPassword(newpwd);
        if(tsl.doUpdateInfo(teacher,teacher.getId())){
            session.removeAttribute("teacher");
            return "login";
        }else{
            return "teacher/personal";
        }
    }

    //修改密码是ajax查询旧密码
    @RequestMapping("checkOld")
    @ResponseBody
    public void toChangeOld(HttpSession session , String old , HttpServletResponse response) throws IOException {
        Teacher teacher = (Teacher)session.getAttribute("teacher");
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out = response.getWriter();
        JSONObject json = new JSONObject();
        if(old.equals(teacher.getPassword())){
            json.append("res","可以");
            out.print(json);
        }else{
            json.append("res","不可以");
            out.print(json);
        }
        out.flush();
        out.close();
    }

    //跳转到自动组卷页面
    @RequestMapping("auto")
    public String toAuto(Model model){
        return "teacher/auto";
    }

    //自动生成试卷操作
    @RequestMapping("auto_new")
    public String toAutoNew(Model model,HttpSession session,HttpServletRequest request){
        if(session.getAttribute("nowList") != null){
            session.setAttribute("nowList",null);
            reomveTestInfo(session);
        }
        String sub = request.getParameter("sub");
        String title = request.getParameter("title");
        String grade = request.getParameter("grade");

        int c_num = Integer.parseInt(request.getParameter("c_num"));
        int f_num = Integer.parseInt(request.getParameter("f_num"));
        int b_num = Integer.parseInt(request.getParameter("b_num"));

        Set<String> nowList = new TreeSet<>();  //存储整套试卷试题ID
        //根据填写题目的数量来随机选择出试题
        if(c_num != 0){
            nowList.addAll(randGetQuestion(c_num,"单选题",sub));
        }
        if(f_num != 0){
            nowList.addAll(randGetQuestion(f_num,"填空题",sub));
        }
        if(b_num != 0){
            nowList.addAll(randGetQuestion(b_num,"大题",sub));
        }

        session.setAttribute("c_num",c_num);
        session.setAttribute("f_num",f_num);
        session.setAttribute("b_num",b_num);
        session.setAttribute("now",nowList.toString().substring(1,nowList.toString().length()-1).replaceAll(" ",""));
        session.setAttribute("nowList",nowList);
        session.setAttribute("sub",sub);
        session.setAttribute("grade",grade);
        session.setAttribute("title",title);
        return "redirect:/nowTest";
    }

    //随机取得type类型的num道题目
    public List<String> randGetQuestion(int num , String type , String sub){
        List<String> ids = qsl.doSelectIdByType(type,sub);
        Collections.shuffle(ids);
        return ids.subList(0,num);
    }

    //注销登录
    @RequestMapping("cancle")
    @ResponseBody
    public void toCancle(HttpSession session){
        session.removeAttribute("teacher");
    }

    //下载试卷
    @RequestMapping("download")
    @ResponseBody
    public void toDownLoad(HttpSession session,HttpServletRequest request,HttpServletResponse response) throws UnsupportedEncodingException {
        Configuration configuration = new Configuration();
        configuration.setDefaultEncoding("UTF-8");
        String paperId = request.getParameter("paperId");
        String title;
        String grade;
        String sub;
        Set<String> nowList = new TreeSet<>();
        String url = "http://" + request.getServerName()+ ":"+ request.getServerPort();
        //首先获取前端的整套试卷的信息
        if(paperId == null || paperId == ""){
            /*1、试卷标题等*/
            title = (String)session.getAttribute("title");
            grade = (String)session.getAttribute("grade");
            sub = (String)session.getAttribute("sub");
            /*2、题目内容*/
            nowList = (Set)session.getAttribute("nowList");
        }else {
            ExamPaper examPaper = epsl.doSelectExamPaper(paperId);
            title = examPaper.getTitle();
            grade = examPaper.getGrade();
            sub = examPaper.getSub();
            if(!examPaper.getQChoice().equals("0")){
                String[]c = examPaper.getQChoice().split(",");
                nowList.addAll(Arrays.asList(c));
            }
            if(!examPaper.getQFill().equals("0")){
                String[]f = examPaper.getQFill().split(",");
                nowList.addAll(Arrays.asList(f));
            }
            if(!examPaper.getQBig().equals("0")){
                String[]b = examPaper.getQBig().split(",");
                nowList.addAll(Arrays.asList(b));
            }
        }
        /*3、z整理试卷内容放入dataMap并下载*/
        Map<String,Object> dataMap = cleanUpPaper(nowList,title,grade,sub,url);
        createWord(configuration,dataMap,response);

        //解决：倒数二（全是<>符号的错！！数据库中的<>最好改成转义符），三（？？）不能打开，(这两个是因为题目中有><这两个符号导致word不能识别，符号问题解决，不用再将&lt;这些转成<,因为word认识)：
        //图片最好都是英文的
    }


/**********************************************整理试卷的方法***********************************************/
    public Map<String,Object> cleanUpPaper(Set<String> nowList,String title , String grade , String sub , String url) throws UnsupportedEncodingException {
        List<String> c_list = new ArrayList<>();
        List<String> f_list = new ArrayList<>();
        List<String> b_list = new ArrayList<>();
        for (String s : nowList) {
            if (s.startsWith("1")) {
                c_list.add(qsl.doSelectQuestionById(s).getContent());
            } else if (s.startsWith("2")) {
                f_list.add(qsl.doSelectQuestionById(s).getContent());
            } else {
                b_list.add(qsl.doSelectQuestionById(s).getContent());
            }
        }
        /*3、处理题目内容并放入dataMap中*/
        Map<String,Object> dataMap=new HashMap<String,Object>();
        //标题等。。
        dataMap.put("title",title);
        dataMap.put("grade",grade);
        dataMap.put("sub",sub);
        //单选题
        List<LinkedHashMap<String,String>> clist = new ArrayList<>();
        for (int i = 0; i < c_list.size(); i++) {
            LinkedHashMap<String,String> map = new LinkedHashMap<>();
            String str = c_list.get(i);

            String content = str.substring(23,str.indexOf("</div>")).replaceAll("<p>","").replaceAll("<br>","")
                    .replaceAll("&nbsp;","").replaceAll("</p>","\r\n")
                    .replaceAll("<","&lt;").replaceAll(">","&gt;");
            int numa = str.indexOf("A、</span><span class=\"op-answer\">")+33;
            int numb = str.indexOf("B、</span><span class=\"op-answer\">")+33;
            int numc = str.indexOf("C、</span><span class=\"op-answer\">")+33;
            int numd = str.indexOf("D、</span><span class=\"op-answer\">")+33;
            String A = str.substring(numa,str.indexOf("</span>",numa)).replaceAll("<","&lt;").replaceAll(">","&gt;");
            String B = str.substring(numb,str.indexOf("</span>",numb)).replaceAll("<","&lt;").replaceAll(">","&gt;");
            String C = str.substring(numc,str.indexOf("</span>",numc)).replaceAll("<","&lt;").replaceAll(">","&gt;");
            String D = str.substring(numd,str.indexOf("</span>",numd)).replaceAll("<","&lt;").replaceAll(">","&gt;");

            map.put("c_content",content.replaceAll("\r\n","</w:t></w:r></w:p><w:p><w:pPr><w:numPr><w:numId w:val=\"0\"/></w:numPr><w:spacing w:line=\"360\" w:lineRule=\"auto\"/><w:ind w:firstLine=\"420\" w:firstLineChars=\"0\"/><w:jc w:val=\"left\"/><w:rPr><w:rFonts w:asciiTheme=\"minorEastAsia\" w:hAnsiTheme=\"minorEastAsia\"/><w:color w:val=\"222222\"/><w:sz w:val=\"24\"/><w:szCs w:val=\"24\"/><w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"FFFFFF\"/></w:rPr></w:pPr><w:bookmarkStart w:id=\"0\" w:name=\"_GoBack\"/><w:bookmarkEnd w:id=\"0\"/><w:r><w:rPr><w:rFonts w:hint=\"eastAsia\" w:asciiTheme=\"minorEastAsia\" w:hAnsiTheme=\"minorEastAsia\"/><w:color w:val=\"222222\"/><w:sz w:val=\"24\"/><w:szCs w:val=\"24\"/><w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"FFFFFF\"/></w:rPr><w:t>"));
            map.put("c_answer_A",A);
            map.put("c_answer_B",B);
            map.put("c_answer_C",C);
            map.put("c_answer_D",D);
            clist.add(map);
        }
        dataMap.put("c_list",clist);
        //填空题
        List<LinkedHashMap<String,String>> flist = new ArrayList<>();
        for (int i = 0; i < f_list.size(); i++) {
            LinkedHashMap<String,String> map = new LinkedHashMap<>();
            String str = f_list.get(i);

            String content = str.substring(23,str.indexOf("</div>")).replaceAll("<p>","").replaceAll("<br>","")
                    .replaceAll("&nbsp;","").replaceAll("</p>","\r\n")
                    .replaceAll("<","&lt;").replaceAll(">","&gt;");
            map.put("f_content",content.replaceAll("\r\n","</w:t></w:r></w:p><w:p><w:pPr><w:numPr><w:numId w:val=\"0\"/></w:numPr><w:spacing w:line=\"360\" w:lineRule=\"auto\"/><w:ind w:firstLine=\"420\" w:firstLineChars=\"0\"/><w:jc w:val=\"left\"/><w:rPr><w:rFonts w:asciiTheme=\"minorEastAsia\" w:hAnsiTheme=\"minorEastAsia\"/><w:color w:val=\"222222\"/><w:sz w:val=\"24\"/><w:szCs w:val=\"24\"/><w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"FFFFFF\"/></w:rPr></w:pPr><w:bookmarkStart w:id=\"0\" w:name=\"_GoBack\"/><w:bookmarkEnd w:id=\"0\"/><w:r><w:rPr><w:rFonts w:hint=\"eastAsia\" w:asciiTheme=\"minorEastAsia\" w:hAnsiTheme=\"minorEastAsia\"/><w:color w:val=\"222222\"/><w:sz w:val=\"24\"/><w:szCs w:val=\"24\"/><w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"FFFFFF\"/></w:rPr><w:t>"));
            flist.add(map);
        }
        dataMap.put("f_list",flist);
        //大题(有一个严重的问题，如果一道大题有两个及以上图片，下载就GG，因为模板只考虑到了一张图片的情况)
        List<LinkedHashMap<String,String>> blist = new ArrayList<>();
        for (int i = 0; i < b_list.size(); i++) {
            LinkedHashMap<String,String> map = new LinkedHashMap<>();
            String str = b_list.get(i);

            String content = str.substring(23,str.indexOf("</div>")).replaceAll("<p>","").replaceAll("<br>","")
                    .replaceAll("&nbsp;","").replaceAll("</p>","\r\n")
                    .replaceAll("<","&lt;").replaceAll(">","&gt;");
            String img;
            String imgurl = null;
            if(content.contains("&lt;img")){
                img = content.substring(content.indexOf("&lt;img"),content.indexOf("&gt;")+4);
                if(img.contains("data:image/png;base64")){
                    imgurl = img.substring(img.indexOf("src=")+27,img.lastIndexOf("class")-2);
                    map.put("img",imgurl);
                }else{
                    String img1 = img.substring(img.indexOf("src=")+5);
                    imgurl = img1.substring(0,img1.indexOf("\""));
                    /*要在tomcat的catalina.bat中设置 set "JAVA_OPTS=%JAVA_OPTS% %JSSE_OPTS%  -Dfile.encoding=UTF-8"*/
                    map.put("img", getImageBase(url + "/img/q_img/" + imgurl.substring(10)));
                }
                content = content.replace(img,"");
            }else {
                map.put("img",null);
            }

            map.put("b_content",content.replaceAll("\r\n","</w:t></w:r></w:p><w:p><w:pPr><w:numPr><w:numId w:val=\"0\"/></w:numPr><w:spacing w:line=\"360\" w:lineRule=\"auto\"/><w:ind w:firstLine=\"420\" w:firstLineChars=\"0\"/><w:jc w:val=\"left\"/><w:rPr><w:rFonts w:asciiTheme=\"minorEastAsia\" w:hAnsiTheme=\"minorEastAsia\"/><w:color w:val=\"222222\"/><w:sz w:val=\"24\"/><w:szCs w:val=\"24\"/><w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"FFFFFF\"/></w:rPr></w:pPr><w:bookmarkStart w:id=\"0\" w:name=\"_GoBack\"/><w:bookmarkEnd w:id=\"0\"/><w:r><w:rPr><w:rFonts w:hint=\"eastAsia\" w:asciiTheme=\"minorEastAsia\" w:hAnsiTheme=\"minorEastAsia\"/><w:color w:val=\"222222\"/><w:sz w:val=\"24\"/><w:szCs w:val=\"24\"/><w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"FFFFFF\"/></w:rPr><w:t>"));
            blist.add(map);
        }
        dataMap.put("b_list",blist);

        return dataMap;
    }

/**********************************************word文档下载的方法****************************************************/
    public void createWord(Configuration configuration,Map<String, Object> dataMap,HttpServletResponse response){
        Template t=null;
        Writer out = null;
        try {
            configuration.setClassForTemplateLoading(this.getClass(),"/");
            t = configuration.getTemplate("word.xml"); //获取模板文件
            response.setContentType("application/x-msdownload;");
            response.setHeader("Content-Disposition", "attachment;filename="+ URLEncoder.encode(
                    (String)dataMap.get("title") + "-" +(String)dataMap.get("sub") + "-" + (String)dataMap.get("grade"),
                    "UTF-8") + ".doc");

            /*out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outFile)));*/
            out = new BufferedWriter(new OutputStreamWriter(response.getOutputStream(),"utf-8"));//wcnm!!!!!!!!,utf-8!!!
            t.process(dataMap, out); //将填充数据填入模板文件并输出到目标文件
        } catch (Exception e1) {
            e1.printStackTrace();
        }finally {
            try {
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /*//获得本地图片的base64码
    public static String getImageBase(String src){
        if (src == null || src == "") {
            return null;
        }
        File file = new File(src);
        if (!file.exists()) {
            return null;
        }
        InputStream in = null;
        byte[] data = null;
        try {
            in = new FileInputStream(file);
            data = new byte[in.available()];
            in.read(data);
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        BASE64Encoder encoder = new BASE64Encoder();
        return encoder.encode(data);
    }*/

    //获取线上图片的base64码
    public static String getImageBase(String imgURL) {
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        try {
            // 创建URL
            URL url = new URL(imgURL);
            byte[] by = new byte[1024];
            // 创建链接
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            InputStream is = conn.getInputStream();
            // 将内容读取内存中
            int len = -1;
            while ((len = is.read(by)) != -1) {
                data.write(by, 0, len);
            }
            // 关闭流
            is.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // 对字节数组Base64编码
        return new String(Base64.getEncoder().encode(data.toByteArray()));
    }
}
