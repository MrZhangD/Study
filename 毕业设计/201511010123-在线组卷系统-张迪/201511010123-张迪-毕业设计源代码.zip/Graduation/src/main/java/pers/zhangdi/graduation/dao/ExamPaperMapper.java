package pers.zhangdi.graduation.dao;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import pers.zhangdi.graduation.vo.ExamPaper;

import java.util.List;

@Repository
public interface ExamPaperMapper {
    //增
    boolean addExamPaper(@Param("paper") ExamPaper exampaper);
    //删
    boolean delExamPaper(@Param("id") String id);
    //查全部
    List<ExamPaper> findAllExamPaper();
    //按照id查询试卷
    ExamPaper findExamPaper(@Param("id") String id);
    //按照作者id查询
    List<ExamPaper> findExamPaperById(@Param("authorid") String authorid);
}
