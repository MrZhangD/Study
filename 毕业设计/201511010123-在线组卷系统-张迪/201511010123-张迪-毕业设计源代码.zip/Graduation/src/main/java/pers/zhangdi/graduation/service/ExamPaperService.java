package pers.zhangdi.graduation.service;

import pers.zhangdi.graduation.vo.ExamPaper;

import java.util.List;

public interface ExamPaperService {
    //增
    boolean doInsertExamPaper(ExamPaper exampaper);
    //删
    boolean doDelExamPaper(String id);
    //查全部
    List<ExamPaper> doSelectAllExamPaper();
    //查询试卷
    ExamPaper doSelectExamPaper(String id);
    //按照作者id查询
    List<ExamPaper> doSelectExamPaperById(String authorid);
}
